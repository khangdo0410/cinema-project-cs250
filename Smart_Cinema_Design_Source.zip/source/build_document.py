"""Build the editable CS 250 design and its matching Markdown source."""
from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from design_model import CLASSES, SERVICES, ENUMS

ROOT=Path(__file__).resolve().parents[1]
doc=Document(); md=[]
sec=doc.sections[0]
sec.page_width=Inches(8.5); sec.page_height=Inches(11)
sec.top_margin=Inches(.68); sec.bottom_margin=Inches(.65)
sec.left_margin=Inches(.72); sec.right_margin=Inches(.72)
sec.header_distance=Inches(.25); sec.footer_distance=Inches(.28)
sec.different_first_page_header_footer=True
styles=doc.styles
for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3','Heading 4','Caption']:
    s=styles[name]; s.font.name='Calibri'; s.font.color.rgb=RGBColor(0,0,0)
styles['Normal'].font.size=Pt(11)
styles['Normal'].paragraph_format.space_after=Pt(6)
styles['Normal'].paragraph_format.line_spacing=1.04
for name,size in [('Heading 1',17),('Heading 2',14),('Heading 3',12),('Heading 4',11)]:
    styles[name].font.size=Pt(size); styles[name].font.bold=True
    styles[name].paragraph_format.space_before=Pt(11)
    styles[name].paragraph_format.space_after=Pt(6)
    styles[name].paragraph_format.keep_with_next=True
styles['Title'].font.size=Pt(29)
styles['Subtitle'].font.size=Pt(18)
styles['Subtitle'].font.italic=False
for style in styles:
    for border in list(style.element.xpath('.//w:pBdr')):
        border.getparent().remove(border)
styles['Caption'].font.size=Pt(9)
styles['Caption'].font.italic=False
styles['Caption'].paragraph_format.space_after=Pt(6)

head=sec.header.paragraphs[0]
head.text='Smart Cinema System  |  Software Design Specification  |  Group 13'
head.runs[0].font.size=Pt(8)
foot=sec.footer.paragraphs[0]; foot.alignment=WD_ALIGN_PARAGRAPH.RIGHT
r=foot.add_run('Design '); r.font.size=Pt(9)
f=OxmlElement('w:fldSimple'); f.set(qn('w:instr'),'PAGE'); foot._p.append(f)

def p(s, style=None, keep=False):
    x=doc.add_paragraph(s,style); x.paragraph_format.keep_with_next=keep
    md.append(s+'\n'); return x
def h(s,level=2):
    doc.add_heading(s,level); md.append('#'*(level+1)+' '+s+'\n')
def br(): doc.add_page_break()
def table(headers,rows,widths=None):
    tb=doc.add_table(rows=1,cols=len(headers)); tb.alignment=WD_TABLE_ALIGNMENT.CENTER; tb.autofit=False
    if not widths: widths=[7.06/len(headers)]*len(headers)
    for i,w in enumerate(widths): tb.columns[i].width=Inches(w)
    pr=tb._tbl.tblPr
    bd=OxmlElement('w:tblBorders')
    for k in ('top','left','bottom','right','insideH','insideV'):
        t=OxmlElement('w:'+k); t.set(qn('w:val'),'single'); t.set(qn('w:sz'),'4'); t.set(qn('w:color'),'D9D9D9'); bd.append(t)
    pr.append(bd)
    for rno,rowvals in enumerate([headers]+list(rows)):
        row=tb.rows[0] if rno==0 else tb.add_row()
        rpr=row._tr.get_or_add_trPr(); ns=OxmlElement('w:cantSplit'); rpr.append(ns)
        if rno==0:
            rp=OxmlElement('w:tblHeader'); rpr.append(rp)
        for i,v in enumerate(rowvals):
            c=row.cells[i]; c.width=Inches(widths[i]); c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            cp=c._tc.get_or_add_tcPr(); mar=OxmlElement('w:tcMar')
            for side in ['top','left','bottom','right']:
                e=OxmlElement('w:'+side); e.set(qn('w:w'),'65' if side in ('top','bottom') else '80'); e.set(qn('w:type'),'dxa'); mar.append(e)
            cp.append(mar)
            sh=OxmlElement('w:shd'); sh.set(qn('w:fill'),'243B53' if rno==0 else ('F3F6F8' if rno%2==0 else 'FFFFFF')); cp.append(sh)
            par=c.paragraphs[0]; par.paragraph_format.space_after=Pt(0); par.paragraph_format.space_before=Pt(0); par.paragraph_format.line_spacing=1.0
            run=par.add_run(str(v)); run.font.size=Pt(9.5)
            if rno==0: run.bold=True; run.font.color.rgb=RGBColor(255,255,255)
    doc.add_paragraph().paragraph_format.space_after=Pt(1)
    md.append('| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |')
    for row in rows: md.append('| '+' | '.join(str(x).replace('\n','<br>') for x in row)+' |')
    md.append('')
    return tb
def op(signature,desc):
    x=doc.add_paragraph(); x.paragraph_format.space_before=Pt(5); x.paragraph_format.space_after=Pt(2); x.paragraph_format.keep_with_next=True
    r=x.add_run(signature); r.font.name='Consolas'; r.font.size=Pt(9.2); r.bold=True
    p(desc)
    md[-1]='`'+signature+'`\n\n'+desc+'\n'
def fig(file,caption,width=6.9):
    x=doc.add_paragraph(); x.alignment=WD_ALIGN_PARAGRAPH.CENTER; x.paragraph_format.space_after=Pt(3); x.paragraph_format.keep_with_next=True
    r=x.add_run(); r.add_picture(str(ROOT/'diagrams'/f'{file}.png'),width=Inches(width))
    inline=r._r.xpath('.//wp:docPr')[0]; inline.set('descr',caption)
    p(caption,'Caption')
    md.append(f'![{caption}](diagrams/{file}.svg)\n')

# Front matter
p('SMART CINEMA SYSTEM','Title')
p('Software Design Specification','Subtitle')
p('Group #13')
for name in ['Khang Do','Minh Nguyen','Phu Pham']: p(name)
p('CS 250 - Introduction to Software Systems')
p('Instructor: Gus Hanna, Ph.D.')
p('Fall 2026')
p('Design version 1.0 | October 7, 2026')
p('Continuation of the Smart Cinema System requirements baseline dated September 22, 2026.')
p('This document defines the software modules, class model, typed interfaces, transaction rules, and development plan for implementing the existing cinema requirements. The design is numbered as Chapter 6 so it can continue the same course project report.')
br()
h('Document guide',1)
table(['Section','Contents'],[
('6.1','System description and scope'),('6.2','SRS interpretation and design assumptions'),('6.3','Software architecture and architectural diagram'),('6.4','UML class diagram in four connected views'),('6.5','Data types, enums, and transfer records'),('6.6','Domain class responsibilities, attributes, and operations'),('6.7','Application services and external interfaces'),('6.8','Transaction rules and booking lifecycle'),('6.9','Persistence, security, and operational behavior'),('6.10','Requirement coverage and verification plan'),('6.11','Development timeline and member responsibilities')],[.7,6.36])
p('Primary reference: Group #13, Smart Cinema System Software Requirements Specification, Version 1.0, September 22, 2026. Source locators below use the SRS section numbers and its printed body pages 1-9; the uploaded PDF has 14 physical pages.')
p('Diagram notation: a minus sign marks a private attribute; a plus sign marks a public operation. A solid line is an association, and a filled diamond marks composition. Multiplicity describes the number of related objects. Full attribute and operation contracts follow the diagrams.')
p('Implementation boundary: a single modular web application and a transactional relational database. This is a design proposal, not a claim that software has been implemented or performance-tested.')
br()
h('6 Software Design Specification',1)
h('6.1 System description')
p('The Smart Cinema System supports one cinema with multiple auditoriums. Customers browse movies and showtimes, select 1-8 seats, pay for tickets, receive QR tickets, review booking history, and cancel an eligible whole booking. Cashiers sell tickets and record cash transactions, ushers verify admission online, and managers maintain the catalog, schedules, prices, layouts, staff roles, reports, and show cancellations.')
p('Every sales channel uses one authoritative seat inventory. A selection is held for five minutes as one unit. The server confirms a booking only after it has verified payment, the show is still available for sale, and all selected seats still belong to the live hold. Email and printing are delivery steps after that decision.')
p('Version 1.0 excludes concessions, loyalty programs, streaming, multi-cinema management, partial cancellation, and seat exchange. Projection equipment remains outside the system. The design preserves the SRS card/cash paths, independent refund object, and single-use admission rule.')
h('6.2 SRS interpretation and design assumptions')
p('The following interpretations resolve wording gaps without removing the underlying requirements. Any later policy change follows the SRS Chapter 5 change process and updates this design and its tests.')
table(['Item and SRS source','Interpretation used in this design'],[
('A1  Sections 3.2.1 and 3.2.2','The processing text is displaced: 3.2.1.3 describes browsing; 3.2.2.3 describes holds. Both clauses are preserved in CatalogService and BookingService. Account behavior comes from their inputs/outputs, Use Case 1, and Section 3.5.4.'),
('A2  Sections 2.3 and 3.4.1','The domain roles Customer, Cashier, Usher, Manager take precedence over generic examples "admin, editor". Multiple roles may belong to one Account.'),
('A3  Sections 3.5.4 and 3.3.3','Guest reservation wording is handled with a scoped guest ownership token and contact email. A guest cannot set another user\'s customerId. Account history requires login; walk-in sales record the cashier and can use printing.'),
('A4  Sections 2.5 and 4.3','Booking stores both a reservation and its later booking state. Card failure or timeout expires the booking. Retry means a new hold after an inventory check. Cash goes directly from HELD to CONFIRMED. No separate two-minute payment deadline is present in this source.'),
('A5  Sections 2.5 and 3.8','Whole-booking cancellation returns the full captured amount, including the saved fees and tax. Fees/tax calculation is configurable. Each successful payment has at most one Refund record; retries update that record.'),
('A6  Sections 2.5 and 3.9','Cancellation is allowed exactly 30 minutes before start if every ticket is unused. Admission uses start minus 30 minutes inclusive to movie end exclusive. Cancellation and scanning serialize on the same booking/ticket records.'),
('A7  Sections 3.4.2 and 3.4.4','Rating and format are descriptive catalog fields. The movie runtime, schedule, layout and receipt values are snapshotted so later catalog edits do not change sold tickets or past receipts.')
],[1.58,5.48])
br()
h('6.3 Software architecture')
p('The browser communicates with a single application server over HTTPS. Request handlers validate input and call six services. Each service owns a small set of use cases; shared data access applies transactions, uniqueness checks, and consistent locking. Background jobs run the same service code for expiry, financial reconciliation, show cancellation, and notification retry.')
fig('architecture','Figure 1. Layered architecture. External calls use adapters; all seat decisions use the same database.',6.7)
br()
h('6.3.1 Component responsibilities',3)
table(['Component','Responsibility'],[
('Presentation and request handlers','Responsive catalog, seat map, checkout, booking history, staff consoles, QR/manual admission and standard printing. Display venue-local times and explicit outcomes. Never decide that a payment succeeded.'),
('AuthService','Registration, profile verification, recovery, login, session expiry, current staff roles and ownership checks.'),
('CatalogService','Movie search, showtime filtering, room/seat layout, configured prices, publication, archiving and schedule conflict checks.'),
('BookingService','Atomic holds, price/receipt snapshots, seat release, ownership, history and eligible whole-booking cancellation.'),
('PaymentService','Card/cash records, verified provider events, one-time confirmation, late payment refunds, reconciliation and cash refund recording.'),
('TicketService','One ticket per paid seat, protected QR credentials, authorized reprint/delivery, online one-time admission and duplicate scan records.'),
('OperationsService','Manager show cancellation, durable cleanup, operational statuses, sales/refund reporting and email retries.'),
('Persistence and jobs','One relational database with row locks and unique keys. Durable notification/refund/cancellation work survives restart. Jobs retry safely using saved keys.'),
('External adapters','PaymentProvider accepts charges/refunds and exposes verified events/status. EmailProvider delivers messages. Providers have no direct authority over seat ownership.')
],[1.76,5.30])
h('6.3.2 Consistency with the existing analysis models',3)
p('The SRS sequence diagram is implemented as payment verification, guarded booking confirmation, ticket creation, and customer confirmation. Its invalid-payment refund branch is handled before any ticket becomes usable. Admission checks consume one ticket atomically and store rejected duplicate scans.')
p('The SRS DFD stores remain logical groups within one database: D1 is Movie, Auditorium, Seat and Showtime; D2 is Booking, BookingSeat, ShowtimeSeat, Ticket and AdmissionAttempt; D3 is Payment, Refund and AuditEvent. Account and notification tables support these processes. The supplied image depicts the customer flow; the staff interfaces call the same services and inventory.')
p('The SRS state-transition diagram is preserved in Section 6.8. Refund state stays in Refund and is not added as a Booking state. An expired or cancelled booking cannot become confirmed after a late callback.')

for n,file,title,caption in [
    (1,'uml_catalog','Catalog and account classes','Figure 2. UML view 1. Catalog entities and account roles.'),
    (2,'uml_booking','Booking and financial classes','Figure 3. UML view 2. Reservation ownership, historical seat lines, payment and refund.'),
    (3,'uml_ticket','Ticket and support classes','Figure 4. UML view 3. Admission, email work and audit records.'),
    (4,'uml_services','Application service classes','Figure 5. UML view 4. Service dependencies and representative typed operations.')]:
    br(); h('6.4 UML class diagram' if n==1 else f'6.4.{n} {title}')
    if n==1: p('The four views describe one class model. A class shown in one view retains the same identity in the other views. Section 6.6 lists all domain fields; Section 6.7 completes the service interfaces.')
    else: p(title+'. The diagrams show representative fields and operations; the following reference specifies the complete major interfaces.')
    fig(file,caption,6.6 if n==4 else 6.8)

br(); h('6.5 Data types and shared records')
table(['Type','Meaning'],[
('UUID','Opaque globally unique identifier, stored with database uniqueness enforcement. Never inferred from a user-entered number.'),
('String, Bytes, Bool','Validated Unicode text, binary bytes, and true/false.'),
('UInt, Int64, Decimal','Nonnegative integer count, signed 64-bit integer money amount, and exact decimal descriptive rating. Money never uses floating point.'),
('Instant, Date, TimeRange','UTC timestamp, calendar date without time, and a pair {start: Instant, end: Instant}. Display/report conversion uses one configured IANA venue time zone.'),
('T?, List<T>, Set<T>, Map<K,V>','Nullable value, ordered collection, distinct collection, and key/value mapping.'),
('Result<T>','{value: T?, error: ErrorCode?, message: String, requestId: UUID}; exactly one of value or error is meaningful. Result<Void> uses an explicit success flag.'),
('Page<T>','{items: List<T>, nextCursor: String?}; page size is validated and bounded.')
],[1.95,5.11])
h('6.5.1 Enumerations',3)
table(['Enum','Allowed values'],ENUMS,[1.75,5.31])
h('6.5.2 Requests and policy records',3)
table(['Record','Fields and validation'],[
('ActorContext','accountId: UUID?, roles: Set<Role>, guestSessionId: UUID?, requestId: UUID. Constructed from verified credentials on the server. A guest context has no staff roles.'),
('RegistrationInput / ProfileInput','Registration: email: String, password: String, name: String, dateOfBirth: Date?. Profile: name: String, dateOfBirth: Date?. Validate lengths and date syntax.'),
('MovieInput','title: String, runtimeMinutes: UInt, rating: Decimal?, language: String, format: String. Positive runtime and nonempty title.'),
('SeatInput','seatId: UUID?, label: String, rowLabel: String, seatNumber: UInt, accessible: Bool, active: Bool. Distinct label and position within the room.'),
('ShowtimeInput','movieId: UUID, auditoriumId: UUID, startsAt: Instant, pricing: PricePolicy. The UI converts a venue-local entry to UTC after resolving daylight-saving ambiguity. End time is computed from the movie runtime.'),
('CatalogFilter / LocalDateRange','Filter: title: String?, localDate: Date?, language: String?, format: String?. Range: firstDate: Date, lastDate: Date inclusive, interpreted in the configured venue zone.'),
('HoldRequest','showtimeId: UUID, seatIds: List<UUID>, customerId: UUID?, contactEmail: String?, channel: SaleChannel. Require 1..8 distinct seats. Customer identity comes from actor; only a cashier may explicitly attach a customer after authorization.'),
('PricePolicy','seatPriceCents: Int64, bookingFeeCents: Int64, taxBasisPoints: UInt, taxableFees: Bool. Amounts are nonnegative and configurable by a manager; taxBasisPoints is bounded to a validated policy range.'),
('PriceQuote','currency: String = USD, seatSubtotalCents: Int64, feeCents: Int64, taxCents: Int64, totalCents: Int64. Frozen when the hold is created.'),
('ReceiptSnapshot','movieTitle: String, runtimeMinutes: UInt, language: String, format: String, auditoriumName: String, startsAt: Instant, endsAt: Instant, venueTimeZone: String, contactEmail: String?, quote: PriceQuote, billingReference: String?. Seat labels and line amounts come from BookingSeat; linked immutable payment data completes the receipt.'),
('AuthPolicy','sessionIdleSeconds: UInt, sessionMaxSeconds: UInt, failureLimit: UInt, lockSeconds: UInt, tokenLifetimeSeconds: UInt, passwordHashParameters: Map<String,String>. Deployment settings require review; the SRS does not provide numeric values.')
],[1.66,5.40])
p('Price calculation: seat subtotal = seat count x seat price. Taxable cents = subtotal + fee only when fees are taxable. Tax cents = floor((taxable cents x tax basis points + 5000) / 10000), using checked/wider integer arithmetic. Total = subtotal + fee + tax. Fee and tax shares are allocated evenly to sorted seat IDs; any remaining cents go to the first lines so line totals exactly equal the saved total.')
h('6.5.3 Responses and provider records',3)
table(['Record','Fields'],[
('SessionView','sessionToken: String, expiresAt: Instant, profile: AccountPublic. Token is delivered in a protected cookie. AccountPublic = {accountId: UUID, name: String, email: String, roles: Set<Role>, status: AccountStatus}; hashes are never returned.'),
('ShowtimeView / SeatView','ShowtimeView = {showtimeId: UUID, movieTitle: String, auditoriumName: String, startsAt: Instant, endsAt: Instant, price: PricePolicy, availableSeats: UInt, selectable: Bool}. SeatView = {seatId: UUID, label: String, accessible: Bool, status: SeatState}; no other customer identity.'),
('BookingView','bookingId: UUID, status: BookingStatus, expiresAt: Instant, receipt: ReceiptSnapshot, seats: List<BookingSeat>, payment: PaymentView?, refund: RefundView?, cancellationCutoff: Instant, ticketIds: List<UUID>.'),
('PaymentView / RefundView','PaymentView = {paymentId: UUID, status: PaymentStatus, amountCents: Int64, method: PaymentMethod}. RefundView = {refundId: UUID, status: RefundStatus, amountCents: Int64, currency: String, reason: RefundReason}; neither exposes provider secrets.'),
('ProviderResult / ProviderEvent','ProviderResult = {transactionId: String, state: ProviderState, amountCents: Int64, currency: String, refundId: String?}. ProviderState = PENDING, SUCCEEDED, FAILED, UNKNOWN. ProviderEvent adds eventId: String, kind: EventKind, paymentId: UUID, refundId: UUID?, payload: Bytes. EventKind = PAYMENT or REFUND; the signature covers the raw payload.'),
('TicketBundle / AdmissionDecision','TicketBundle = {bookingId: UUID, tickets: List<TicketView>}; TicketView = {ticketId: UUID, seatLabel: String, token: String, status: TicketStatus}. AdmissionDecision = {result: AdmissionResult, ticketId: UUID?, seatLabel: String?, message: String}.'),
('CancellationSummary / SalesReport','CancellationSummary = {showtimeId: UUID, affectedBookings: UInt, pendingCleanup: UInt, pendingRefunds: UInt}. SalesReport = {range: LocalDateRange, cardSalesCents: Int64, cashSalesCents: Int64, refundsPaidCents: Int64, netCents: Int64, refundsDueCents: Int64, soldSeats: UInt}.'),
('ServiceStatus','paymentHealth: HealthState, emailHealth: HealthState, unknownPayments: UInt, refundsDue: UInt, failedMessages: UInt, explanations: Map<String,String>. HealthState = AVAILABLE, DEGRADED, UNAVAILABLE.'),
('ErrorCode','INVALID_INPUT, UNAUTHENTICATED, FORBIDDEN, NOT_FOUND, CONFLICT, SOLD_OUT, HOLD_EXPIRED, SHOW_UNAVAILABLE, CUTOFF_PASSED, TICKET_USED, PAYMENT_UNCERTAIN, PROVIDER_UNAVAILABLE. Error responses never imply a completed charge/refund without evidence.')
],[1.76,5.30])

br(); h('6.6 Domain class specifications')
p('Domain methods are called by authorized services. Methods that change several records run inside a DataStore transaction; callers cannot persist a single seat or ticket update independently. The database supplies the current UTC time for a decision after locks are acquired. Fields marked nullable remain null until their stated event occurs.')
for i,c in enumerate(CLASSES,1):
    h(f'6.6.{i} {c["name"]}',3)
    p(c['purpose']); p(c['relations'])
    table(['Attribute','Type','Description'],c['attrs'],[1.72,1.02,4.32])
    for signature,desc in c['ops']: op(signature,desc)

br(); h('6.7 Application services and function interfaces')
p('Every public write validates request fields, authorizes the actor and ownership, and uses a unique request key. Repeating the same actor/action/key and request body returns the saved result; reusing that key with a different body returns CONFLICT. Client timestamps are never trusted. Worker-only methods are internal entry points and cannot be invoked directly by an ordinary browser session.')
p('Expected business failures use Result<T>. Void domain methods report invalid transitions to their calling service, which rolls back the transaction. Unexpected database failures also roll back, return a safe error, and write operational diagnostics without secrets.')
for i,s in enumerate(SERVICES,1):
    h(f'6.7.{i} {s["name"]}',3); p(s['purpose'])
    table(['Dependency attribute','Type','Responsibility'],s['attrs'],[1.5,1.3,4.26])
    for signature,desc in s['ops']: op(signature,desc)
h('6.7.7 Infrastructure interfaces',3)
op('DataStore.transaction<T>(work: TransactionWork<T>): Result<T>','Begins, commits or rolls back a unit of work. TransactionWork<T> = (repositories: RepositorySet): T is a callback receiving repositories bound to that transaction; RepositorySet is the typed collection of transaction-bound domain repositories. Repositories offer getById(id: UUID), save(entity: T), and the locked queries below; business guards remain in services.')
table(['Interface operation','Return','Contract'],[
('lockShow(showtimeId: UUID)','Showtime','Row lock shared by sales, cancellation and admission.'),
('lockBooking(bookingId: UUID)','Booking','Row lock for lifecycle and cancellation/admission serialization.'),
('lockSeats(showtimeId: UUID, seatIds: List<UUID>)','List<ShowtimeSeat>','Locks distinct seat keys in sorted order; returns exactly the requested existing rows or fails.'),
('lockTickets(bookingId: UUID)','List<Ticket>','Locks all booking tickets before whole-booking cancellation or admission.'),
('findExpired(now: Instant, limit: UInt)','List<UUID>','Bounded candidate scan; the transaction rechecks each candidate before mutation.'),
('findByTokenHash(hash: String)','Ticket?','Unique indexed lookup; never scans decrypted tokens.'),
('Clock.now()','Instant','Server/database UTC time; controllable test clock for boundary tests.'),
('TokenProtector.createToken()','String','Cryptographically secure random token with at least 128 bits of entropy.'),
('TokenProtector.hash(token: String)','String','Cryptographic lookup hash for high-entropy tokens; passwords use a separate adaptive password hash.'),
('TokenProtector.encrypt(token: String) / decrypt(value: Bytes)','Bytes / String','Authenticated encryption/decryption; key comes from protected server configuration, separate from database backups.')
],[3.15,1.05,2.86])
op('PaymentProvider.charge(paymentId: UUID, amountCents: Int64, currency: String, paymentToken: String, key: UUID): ProviderResult','Accepts a provider-issued payment token, unique request key, and exact amount. An uncertain transport outcome is returned as UNKNOWN. The same key must return the same transaction rather than charge again.')
op('PaymentProvider.refund(transactionId: String, amountCents: Int64, key: UUID): ProviderResult','Returns funds from the original successful transaction. Reconciliation uses getPayment(transactionId: String): ProviderResult and getRefund(refundId: String): ProviderResult; when a reference is missing, getByKey(key: UUID): ProviderResult resolves the original operation.')
op('PaymentProvider.verifyEvent(payload: Bytes, signature: String): Bool','Checks the configured provider signature and event freshness before any business record is changed. Verified unique event IDs are persisted with handling status to prevent replay.')
op('EmailProvider.send(message: EmailMessage, key: String): DeliveryResult','EmailMessage = {to: String, subject: String, body: String}; DeliveryResult = {accepted: Bool, providerMessageId: String?, retryable: Bool}. Use notification.dedupeKey as a stable provider message key where supported. Delivery is at-least-once if the provider cannot deduplicate after an uncertain send; it never creates a second ticket or booking.')

h('6.8 Transaction rules and lifecycle')
h('6.8.1 Holding and expiring seats',3)
p('Use row-level transactions with a consistent lock order: auditorium when scheduling, then showtime, affected bookings ordered by ID, inventory rows ordered by seat ID, tickets, financial records, and supporting records. Within one show, its row lock serializes competing sales and cancellations. Never hold database locks while waiting on payment or email network calls.')
for s in [
'1. Validate an actor-scoped request key, one bookable show, and 1-8 distinct selected seat IDs belonging to its frozen layout.',
'2. Start a transaction and lock the show. Read the database clock and reject now >= startsAt or a nonpublished show. Identify and lock any expired owner bookings before their inventory rows; expire them and clear only their owned allocations.',
'3. Lock every selected ShowtimeSeat in sorted order. If any row is absent, held by another live booking, or SOLD, roll back the whole request.',
'4. Create one HELD Booking with expiresAt = now + 300 seconds, immutable quote/receipt and 1-8 BookingSeat rows. Claim every selected inventory row. Save the request result and audit event, then commit.',
'5. An expiry worker scans by status/expiry, locks and rechecks candidates, transitions live unpaid bookings to EXPIRED, and clears owned rows. Hold creation and availability reads also run expiry cleanup so a delayed worker cannot preserve an invalid hold.'
]: p(s)
p('Seat availability is informational until step 4 commits. A second browser session cannot override a committed allocation. The database primary key allows only one ShowtimeSeat row per show/seat; owner-checked updates and the transaction enforce one live owner across both sales channels.')
h('6.8.2 Payment confirmation and recovery',3)
p('Starting card payment moves HELD to PAYMENT_PENDING without extending the hold. The server persists one Payment and its provider key before sending a charge request. Cashier cash collection takes the direct HELD to CONFIRMED path only after tender, show validity and seat ownership are checked.')
p('On a verified card success, lock the show, booking, all selected inventory rows and payment. Read current server time. Require a live PAYMENT_PENDING booking, now < expiresAt, now < startsAt, PUBLISHED show, matching amount/currency, and every seat still HELD by this booking. In one transaction record success, mark every seat SOLD, confirm the booking, issue all tickets, append audit, and queue confirmation email. If any write fails, roll back the entire confirmation and reconcile the provider transaction.')
p('If funds were captured but any guard fails, store the financial result, expire a still-live invalid booking when appropriate, release its owned holds, and create/reuse a single INVALID_PAYMENT Refund. Keep EXPIRED or CANCELLED terminal. A missing/forged callback, browser success redirect, amount mismatch, or UNKNOWN result never creates a usable ticket. A mismatch is investigated and refunded against the actual verified captured amount, not the requested quote amount.')
p('A definitive card failure moves PAYMENT_PENDING to EXPIRED and releases seats. An uncertain payment remains UNKNOWN and is reconciled while the five-minute hold may still be live; it expires at the existing deadline. An eventual late success produces a refund. Retrying checkout after an expired/failed booking starts a new booking with a new inventory check. A replay of an already accepted success returns its saved result; it does not reevaluate the original confirmation as a new late purchase.')
h('6.8.3 Cancellation and admission',3)
p('Customer, cashier or manager booking cancellation locks the booking and all its tickets. Require now <= startsAt - 30 minutes and no USED ticket. Atomically cancel the full booking, void all tickets, release owned seat allocations, create/reuse the refund, append audit, and queue cancellation email. A card refund is processed after commit; a cash refund stays CASH_DUE until the cashier records actual payment. Cancellation is not undone when refund delivery is delayed.')
p('Manager cancellation first locks a future show, requires now < startsAt, marks it CANCELLED and creates durable cleanup work. That committed flag immediately blocks all new holds, confirmations and admissions. A restartable worker cancels every affected active booking, voids tickets, releases allocations and creates one refund per successful payment. It continues monitoring pending payments; any later success is refunded. Reporting distinguishes cleanup/refunds pending from completed work.')
p('Admission hashes a scanned or manually entered token. The online server verifies authorization, show state, paid confirmed booking, ticket state and the time window. It locks the same show/booking/ticket used by cancellation, then changes VALID to USED and records one ACCEPTED attempt. Two concurrent scans cannot both succeed. A new scan of a USED ticket is DUPLICATE and logged; retrying the same attemptId returns its earlier decision. Reprinting the same token cannot reset admission.')
h('6.8.4 Booking transitions',3)
table(['From','Trigger and guard','To'],[
('HELD','Start a card payment while hold, show and seats remain valid.','PAYMENT_PENDING'),
('HELD','Authorized cashier records valid cash payment and sufficient tender.','CONFIRMED'),
('HELD','Five-minute hold deadline is reached.','EXPIRED'),
('HELD','Owner releases hold or manager cancels future show.','CANCELLED'),
('PAYMENT_PENDING','Verified successful payment and all confirmation guards pass.','CONFIRMED'),
('PAYMENT_PENDING','Definitive failure, invalid confirmation, or hold deadline.','EXPIRED'),
('PAYMENT_PENDING','Owner releases hold or manager cancels future show; keep payment reconcilable.','CANCELLED'),
('CONFIRMED','Eligible whole-booking cancellation, or manager cancels future show.','CANCELLED'),
('EXPIRED / CANCELLED','Any later payment event; record/refund funds separately.','No booking transition')
],[1.36,4.34,1.36])

br(); h('6.9 Persistence and operational design')
h('6.9.1 Keys and database constraints',3)
table(['Record or constraint','Implementation rule'],[
('Entity IDs and references','UUID primary keys; foreign keys preserve relationships. Use logical archive/deactivation instead of deleting referenced catalog, account or financial data.'),
('Account and catalog','Unique normalized Account.email; unique (auditoriumId, label) and (auditoriumId, rowLabel, seatNumber). Positive movie runtime and valid start/end intervals.'),
('Inventory','Primary key (showtimeId, seatId). AVAILABLE requires null owner; HELD/SOLD require an owner for the same show. Transactional guards prevent two active allocations. Frozen show layouts must match the auditorium.'),
('Booking lines and tickets','Unique (bookingId, seatId) on BookingSeat and Ticket; Ticket references that composite key. Enforce 1..8 lines at service commit; an optional deferred database check can enforce aggregate count. Unique tokenHash.'),
('Payment and refund','Unique Payment.bookingId, payment idempotencyKey and nonnull providerTransactionId. Unique Refund.paymentId, refund idempotencyKey and nonnull providerRefundId. Nonnegative integer amounts; refunds cannot exceed verified captured funds.'),
('Admission and idempotency','Unique attemptId; a conditional update and unique accepted-ticket constraint permit one accepted admission per ticket. RequestRecord key = (actorScope, action, key); stores requestHash and resultRef. Same key/different request is a conflict.'),
('Provider and work records','ProviderEventRecord key = (provider, eventId), with verified payload hash, state and result. Unique notification dedupeKey; unique cancellation job per show. Persist intent before external calls.'),
('Snapshots and retention','Keep original receipt, BookingSeat lines and immutable payment facts. Never recalculate a past receipt from the current catalog. Do not hard-delete confirmed booking/payment/refund data as part of normal operations.')
],[1.76,5.30])
p('Supporting persistence records are implementation structures rather than additional business classes: SessionRecord(sessionId: UUID, accountId: UUID, tokenHash: String, createdAt: Instant, lastActivityAt: Instant, expiresAt: Instant, roleVersion: UInt, revokedAt: Instant?); AuthTokenRecord(tokenId: UUID, accountId: UUID, tokenHash: String, encryptedToken: Bytes, purpose: TokenPurpose, expiresAt: Instant, consumedAt: Instant?); RequestRecord(requestId: UUID, actorScope: String, action: String, key: UUID, requestHash: String, resultRef: UUID?); ProviderEventRecord(provider: String, eventId: String, payloadHash: String, processedAt: Instant?); CancellationJob(showtimeId: UUID, cursor: UUID?, finished: Bool).')
p('Account role changes increment the current authorization version stored with account roles; every protected request checks the current record. Role revocation takes effect immediately even if an older browser session remains open. Provider event receipt and business changes are committed together, or the event stays unprocessed for retry.')
h('6.9.2 Security and user experience',3)
p('Use HTTPS, protected cookies, server-side session expiry, request forgery protection for cookie-authenticated writes, and a salted adaptive password hash. Recovery and verification tokens are random, single-use, hash-indexed and expiring. Encrypted backups support delivery where required. Never log passwords, raw session/recovery/QR tokens, full card details or provider secrets.')
table(['Role','Allowed actions'],[
('Guest','Browse and use only a reservation bound to its own guest token/contact. Cannot choose another account ID or read account history.'),
('Customer','Browse, manage own verified profile, create/pay/release own holds, see own history, retrieve own tickets and cancel eligible own bookings.'),
('Cashier','Sell through the shared inventory, record card/cash sales, print/reprint permitted tickets, cancel eligible bookings and record cash refunds actually paid.'),
('Usher','Online QR/manual validation and limited ticket/show details needed for admission.'),
('Manager','Catalog/layout/pricing/schedule management, staff-role assignment, future-show cancellation, authorized refunds, operational reports and status. Cashier/usher privileges require those roles explicitly.')
],[1.16,5.90])
p('The public interface uses responsive layouts, keyboard navigation, clear text labels and non-color-only seat states. The confirmation/cancellation views show venue-local cancellation cutoff and independent refund status. The staff console explains expired holds, unknown payment outcomes, duplicate scans, printing errors and cash refunds due. Camera permission failure offers manual token entry. A printing failure offers reprint without creating a new ticket.')
h('6.9.3 Reliability and performance',3)
p('Index shows by publication/start/movie, allocation rows by show/seat, unpaid bookings by status/expiry, tickets by token hash, payments/refunds by provider reference and status, and notification work by state/next attempt. Keep lock transactions short; batch worker tasks and paginate history/report queries. No cache may override the database when confirming a hold, purchase or admission.')
p('Measure under the SRS load: 500 concurrent browsers, 50 concurrent checkouts, up to 10 auditoriums with 300 seats each, and client round-trip latency no greater than 100 ms. Record catalog, hold, confirmation and admission latency separately from third-party time. A p95 target of 2 seconds for internal requests is a proposed interpretation of "a couple of seconds," not a completed benchmark. Verify expiry at the deadline through request-time cleanup and measure worker cleanup lag.')
p('Use database backups and a documented restore drill. After restart, resume pending provider reconciliation, show-cancellation and email work. A committed confirmed booking must retain matching payment, sold seats and tickets; an uncommitted partial transaction must not appear. Deployment includes schema migration, regression checks and a rollback plan. The SRS does not specify numeric backup recovery or uptime targets, so those operational settings require agreement before deployment.')

br(); h('6.10 Requirement coverage and verification')
p('These are planned acceptance checks, not claimed test results. SRS section references identify the source; the T labels identify design tests and do not replace missing SRS requirement IDs. Every service change should update the linked checks.')
table(['Test and SRS source','Design and acceptance check'],[
('T01  2.5, 3.3.3','BookingService.createHold: reject 0, 9 or duplicate seats; accept 1 and 8. Competing overlapping selections produce one complete winner and no partial loser hold.'),
('T02  3.3.3, 3.2.2.3','At expiresAt - 1 ms the owned hold may confirm; at expiresAt it cannot. Expiry releases all owned seats. A delayed old worker cannot release seats acquired by a newer booking.'),
('T03  3.6, 3.7','Run online and box-office requests concurrently for the same show/seat. Unique allocation plus locked confirmation never creates two active owners or paid tickets for the same active allocation.'),
('T04  2.5, 3.2.1.3','At now = startsAt, new holds and confirmations fail. Cancelled, draft, sold-out and started shows are not selectable. A stale catalog response cannot bypass purchase checks.'),
('T05  4.1, 3.6','A browser success redirect alone creates no ticket. Signed success with a wrong amount/currency or invalid/expired allocation records funds for investigation/refund and creates no usable ticket.'),
('T06  3.1.3, 3.8','Replay request/event IDs before and after the hold deadline. Charge, confirmation, ticket creation and refund effects occur once. A conflicting body under the same key is rejected.'),
('T07  2.5, 4.3','Cashier sale validates tender and exact change; a customer cannot record cash. Valid cash goes HELD to CONFIRMED atomically. Failed cash validation leaves no successful payment.'),
('T08  3.8, 3.1.2','Confirmed booking has one QR ticket per BookingSeat. Reprint uses the same encrypted token backup and same ticket IDs; tokens/hashes are unique and raw tokens stay out of logs.'),
('T09  2.5, 4.1','Before start-30 minutes reject admission; exactly at that time permit an unused paid ticket. At movie end reject. Concurrent different scan IDs accept once, reject/log the duplicate; same attempt ID returns the prior result.'),
('T10  2.5, 3.9','At start-30 minutes a whole unused booking may cancel; 1 ms later it may not. Any used ticket blocks customer cancellation. Concurrent cancellation/admission gives one valid serialized outcome.'),
('T11  3.8, 4.3','Repeated cancellation/refund retry produces one Refund per successful Payment. Unknown card refund is reconciled. Cash refund stays CASH_DUE until a cashier records actual disbursement.'),
('T12  2.5, 4.1','Cancel a future show while holds, payments and scans are active. Show flag blocks new work immediately; restartable cleanup cancels bookings, voids tickets and refunds known/late successes once.'),
('T13  2.5, 3.4','Two schedules in one room require at least 20 minutes after movie end in either order. Concurrent scheduling cannot overlap; cancel/create replaces a sold show instead of silently moving ticket times.'),
('T14  3.4, 3.8','Layout edits affect new shows only. Historic receipts keep original movie/time/room/seat/amount values after catalog edits. Referenced records cannot be hard-deleted.'),
('T15  3.2.1, 3.3.1, 3.5.4','Register/verify/login/recover with duplicate email, invalid or reused token, locked account and expired session. Generic recovery messages prevent account disclosure. Roles removed by manager stop working on the next request.'),
('T16  3.5.4, 3.7','A customer cannot access another booking; a guest cannot impersonate an account. Every staff operation enforces its required role. Audit changes commit with financial/booking state and expose no secrets.'),
('T17  3.5.2, 3.5.3','Crash after provider success but before local commit. Reconciliation produces one valid booking or one refund. Email outage leaves the booking valid and retries the same notification.'),
('T18  3.7, 3.9','Verify USD cent arithmetic including rounding/remainders and overflow. Store UTC; show receipt, cutoff and report dates in the configured venue zone, including daylight-saving boundaries.'),
('T19  3.5.1, 3.5.6','Measure stated load/latency profile. Test mobile/tablet/desktop layout, keyboard flow, text labels, manual ticket entry and browser printing.'),
('T20  2.2, 3.5.2, 3.9','Reports separate captured sales, refunds paid, pending refunds and net receipts. Restore a backup and replay durable work without duplicate seats, tickets or money effects.')
],[1.65,5.41])

h('6.11 Development plan and timeline')
p('The proposed plan covers four development weeks after the team approves the design. The course deadline was not supplied, so weeks are relative rather than invented due dates. Each member owns implementation, tests and documentation for a comparable portion; every merge receives a review from another member.')
table(['Phase','Task and responsible member','Expected output'],[
('Week 1','Khang Do: application module structure, transaction rules, booking/inventory schema and UML integration.','Shared interface definitions; migration outline; concurrency scenarios T01-T04.'),
('Week 1','Minh Nguyen: account/role model, catalog, auditorium/seat layout and showtime interfaces.','Auth/catalog contracts; scheduling and role scenarios T13-T16.'),
('Week 1','Phu Pham: payment/refund, ticket/admission and external-provider contracts.','Provider test doubles; finance/admission scenarios T05-T12.'),
('Week 2','Khang Do: holds, expiry, history and ownership; Minh reviews.','Atomic 1-8 seat flow; release/retry behavior; booking screens.'),
('Week 2','Minh Nguyen: registration/login/recovery, catalog/search, manager layout and schedule editing; Phu reviews.','Verified accounts; protected roles; conflict-free published showtimes.'),
('Week 2','Phu Pham: card/cash flow, protected QR tickets, scan/reprint and basic email; Khang reviews.','Paid confirmation path; duplicate-safe tickets and online admission.'),
('Week 3','Khang Do: customer cancellation and whole-system concurrency integration.','Cutoff/race handling; no partial holds or double allocations.'),
('Week 3','Minh Nguyen: manager show cancellation UI, operational reports, role and accessibility tests.','Clear cancellation/refund statuses; correct local-time reports.'),
('Week 3','Phu Pham: late-payment/refund reconciliation, durable notification and cancellation workers.','Restart-safe financial cleanup and notification retry; failure tests.'),
('Week 4','All members: integrate, run T01-T20, review migrations/restore/rollback, revise design. Khang compiles; Minh checks SRS coverage; Phu checks diagrams and financial states.','Recorded test results; corrected interfaces; readable final PDF; tagged submission files and repository link.')
],[.72,3.87,2.47])
h('6.11.1 Team member responsibilities',3)
table(['Member','Primary ownership','Review responsibility'],[
('Khang Do','Architecture, Booking/BookingSeat/ShowtimeSeat, inventory transactions, history/cancellation integration and final document assembly.','Review payment/admission integration; verify atomic confirmation and receipt consistency.'),
('Minh Nguyen','Account and role flows; Movie/Auditorium/Seat/Showtime; scheduling, manager UI and reports.','Review booking ownership and expiry; check SRS coverage and time/price presentation.'),
('Phu Pham','Payment/Refund/Ticket/AdmissionAttempt, notifications, provider adapters and reconciliation jobs.','Review auth/catalog permissions and schedule boundaries; verify financial and scan failure cases.')
],[1.14,3.53,2.39])
h('6.11.2 Milestones and completion criteria',3)
p('Week 1 ends when the schema, UML and service contracts agree. Week 2 ends with one vertical path from browsing through a paid ticket and online admission. Week 3 ends when cancellation, provider failure, late callback, duplicate request and crash recovery paths behave consistently. Week 4 ends after planned checks have recorded outcomes, defects are resolved or explicitly tracked, and the requirements-plus-design report is exported and reviewed.')
p('A task is complete only when its owner updates the affected source/design, records meaningful verification, and another member reviews it. These assignments describe planned responsibility; they do not certify work or commits already completed by any member.')
h('6.11.3 Repository contribution plan',3)
p('Keep the existing requirements files and append this Design chapter to the same project report. Store the editable design and diagram source beside the PDF so later assignments can continue the document. Use small descriptive commits and preserve unrelated repository work.')
table(['Member','Individual contribution to commit and push'],[
('Khang Do','Review and commit the architecture, booking/inventory design, integrated report and PDF export under his own GitHub identity.'),
('Minh Nguyen','Individually review and improve account/catalog/showtime design, then add concrete role and scheduling boundary test cases with expected results. Commit and push those edits himself.'),
('Phu Pham','Individually review and improve payment/refund/admission design, then add concrete late-payment, refund and duplicate-scan test cases with expected results. Commit and push those edits himself.')
],[1.14,5.92])
p('Each member must push at least one real commit as required by the assignment. One person uploading files, listing all three names, or adding a co-author label does not demonstrate that each member pushed. After all three contributions are visible in the repository history, one group member submits the link to the final combined PDF. Verify the instructor can access the repository.')

doc.core_properties.title='Smart Cinema System Software Design Specification'
doc.core_properties.subject='CS 250 Group 13 Software Design'
doc.core_properties.author='Group 13 - Khang Do, Minh Nguyen, Phu Pham'
doc.core_properties.keywords='Smart Cinema; Software Design; CS 250; Group 13'
doc.save(ROOT/'Smart_Cinema_System_Software_Design_Specification.docx')
(ROOT/'Smart_Cinema_System_Software_Design_Specification.md').write_text('\n'.join(md),encoding='utf-8')
print('Created DOCX and Markdown source')
