"""Append the verified Design chapter to the preserved SRS body."""
from pathlib import Path
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
import fitz, shutil, re

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'Smart_Cinema_System_SRS_Original.pdf'
DESIGN=ROOT/'Smart_Cinema_System_Software_Design_Specification.pdf'
if not SOURCE.exists() or not DESIGN.exists():
    raise FileNotFoundError('Keep the original SRS PDF and exported Design PDF in the project root before assembling the report.')
base=fitz.open(SOURCE); design=fitz.open(DESIGN)

# Correct a typographical artifact in a copy, without changing the money rule.
pg=base[10]
rect=fitz.Rect(71.8,420.6,539.3,434.6)
pg.add_redact_annot(rect,fill=(1,1,1)); pg.apply_redactions(images=0,graphics=0)
pg.insert_text((72,431.689453125),'optional. Money amounts in the database shall be stored in integers denoting cents, and',fontname='tiro',fontsize=12,color=(0,0,0))

styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='ReportTitle',fontName='Helvetica-Bold',fontSize=26,leading=31,spaceAfter=20))
styles.add(ParagraphStyle(name='ReportSubtitle',fontName='Helvetica',fontSize=17,leading=22,spaceAfter=25))
styles.add(ParagraphStyle(name='BodyCustom',fontName='Helvetica',fontSize=10.5,leading=15,spaceAfter=9))
styles.add(ParagraphStyle(name='SmallCustom',fontName='Helvetica',fontSize=9,leading=12,spaceAfter=7))
styles.add(ParagraphStyle(name='CellCustom',fontName='Helvetica',fontSize=9.4,leading=13))
styles.add(ParagraphStyle(name='CellHead',fontName='Helvetica-Bold',fontSize=9.4,leading=13,textColor=colors.white))
story=[]
def p(s,st='BodyCustom'): story.append(Paragraph(s,styles[st]))
def tab(head,rows,widths):
    dat=[[Paragraph(str(x),styles['CellHead']) for x in head]]+[[Paragraph(str(x),styles['CellCustom']) for x in r] for r in rows]
    t=Table(dat,colWidths=widths,hAlign='LEFT',repeatRows=1)
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#243B53')),('GRID',(0,0),(-1,-1),.4,colors.HexColor('#D9D9D9')),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F3F6F8')])]))
    story.append(t); story.append(Spacer(1,12))
p('SMART CINEMA SYSTEM','ReportTitle')
p('Software Requirements and Design','ReportSubtitle')
p('Group #13<br/>Khang Do<br/>Minh Nguyen<br/>Phu Pham')
p('CS 250 - Introduction to Software Systems<br/>Instructor: Gus Hanna, Ph.D.<br/>Fall 2026')
story.append(Spacer(1,18))
p('Project Report Version 1.1<br/>October 7, 2026')
p('This report continues the same Smart Cinema System project. It combines the existing requirements baseline with the Software Design Specification, including the architecture, UML class model, typed interfaces, transaction rules, and team development plan.')
tab(['Version','Date','Content'],[['1.0','September 22, 2026','Existing Software Requirements Specification'],['1.1','October 7, 2026','Requirements retained and Software Design chapter added']],[55,133,316])
p('The requirements remain the baseline for development. Design interpretations are documented in Section 6.2, and the implementation and verification work is planned in Sections 6.10 and 6.11.','SmallCustom')
story.append(PageBreak())
p('Report contents','ReportSubtitle')
rows=[['Requirements and analysis','3-11'],['Design document guide','12']]
bookmarks=[]
for prefix in ['6.1 System description','6.2 SRS interpretation','6.3 Software architecture','6.4 UML class diagram','6.5 Data types','6.6 Domain class','6.7 Application services','6.8 Transaction rules','6.9 Persistence','6.10 Requirement coverage','6.11 Development plan']:
    for i in range(2,len(design)):
        lines=design[i].get_text().splitlines()
        found=next((x for x in lines if x.startswith(prefix)),None)
        if found:
            report_page=i+11
            rows.append([found,str(report_page)]); bookmarks.append((found,report_page)); break
tab(['Section','PDF page'],rows,[451,53])
p('The contents above use PDF page numbers. The retained requirement pages keep their original SRS page labels, and the Design chapter keeps its Design page labels for easier cross-reference.','SmallCustom')
p('Editorial record: the nine requirements-body pages and the original analysis diagrams are retained. The unused template cover, placeholder approval/revision material, and obsolete contents were replaced with this front matter. A typographical artifact in the integer-cents sentence was corrected without changing the requirement. The unmodified original PDF is preserved separately.','SmallCustom')

temp_dir=ROOT/'tmp'
temp_dir.mkdir(exist_ok=True)
front=temp_dir/'report_front.pdf'
SimpleDocTemplate(str(front),pagesize=(612,792),rightMargin=54,leftMargin=54,topMargin=54,bottomMargin=48,title='Smart Cinema System Software Requirements and Design',author='Group 13').build(story)
f=fitz.open(front)
assert len(f)==2, f'Front matter overflow: {len(f)}'
combined=fitz.open(); combined.insert_pdf(f); combined.insert_pdf(base,from_page=5,to_page=13); combined.insert_pdf(design,from_page=1)
combined.set_metadata({'title':'Smart Cinema System Software Requirements and Design','author':'Group 13 - Khang Do, Minh Nguyen, Phu Pham','subject':'CS 250 cumulative project report version 1.1','keywords':'Software Requirements; Software Design; Smart Cinema; CS 250'})
toc=[[1,'Report cover',1],[1,'Report contents',2],[1,'Software Requirements Specification',3]]
for label,num in [('1 Introduction',3),('2 General Description',4),('3 Specific Requirements',5),('4 Analysis Models',9),('5 Change Management and Appendices',11)]: toc.append([2,label,num])
toc.append([1,'6 Software Design Specification',12])
toc.extend([[2,label,page] for label,page in bookmarks])
combined.set_toc(toc)
combined.save(ROOT/'Smart_Cinema_System_Project_Report.pdf',garbage=4,deflate=True)
print('Cumulative PDF pages:',len(combined),'Design PDF pages:',len(design))
print('Design headings:',bookmarks)

# Preserve editable vector figures in a flat repository layout for Markdown links.
for svg in (ROOT/'diagrams').glob('*.svg'): shutil.copy2(svg,ROOT/svg.name)
md=ROOT/'Smart_Cinema_System_Software_Design_Specification.md'
md.write_text(md.read_text().replace('](diagrams/',']('),encoding='utf-8')
