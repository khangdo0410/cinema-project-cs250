"""Generate vector architecture/UML diagrams and print-resolution PNGs."""
from pathlib import Path
from reportlab.graphics.shapes import Drawing, Rect, Line, String, Polygon, PolyLine
from reportlab.graphics import renderPDF, renderSVG
from reportlab.lib.colors import HexColor, white
import fitz

OUT = Path(__file__).resolve().parents[1] / 'diagrams'
OUT.mkdir(exist_ok=True)
INK=HexColor('#22313f'); LIGHT=HexColor('#e7eef4'); GRAY=HexColor('#576675')

class Diagram:
    def __init__(self, name, w=510, h=610):
        self.name=name; self.w=w; self.h=h; self.d=Drawing(w,h)
        self.d.add(Rect(0,0,w,h,fillColor=white,strokeColor=None))
    def text(self,x,y,s,size=10,bold=False,align='start',color=INK):
        self.d.add(String(x,self.h-y,s,fontName='Helvetica-Bold' if bold else 'Helvetica',fontSize=size,fillColor=color,textAnchor=align))
    def box(self,x,y,w,h,title,attrs=(),ops=(),ref=False):
        self.d.add(Rect(x,self.h-y-h,w,h,fillColor=white,strokeColor=INK,strokeWidth=.8,strokeDashArray=[4,3] if ref else None))
        self.d.add(Rect(x,self.h-y-25,w,25,fillColor=LIGHT,strokeColor=INK,strokeWidth=.8))
        self.text(x+w/2,y+17,title,11,True,'middle')
        yy=y+40
        for s in attrs:
            self.text(x+8,yy,s,9.2); yy+=13
        if ops:
            yy+=1; self.d.add(Line(x,self.h-yy,w+x,self.h-yy,strokeColor=INK,strokeWidth=.65)); yy+=15
            for s in ops:
                self.text(x+8,yy,s,9.2); yy+=13
        assert yy <= y+h+5, (title,yy,y+h)
    def link(self,pts,a='',b='',label='',composition=False,dashed=False,arrow=False):
        v=[q for x,y in pts for q in (x,self.h-y)]
        self.d.add(PolyLine(v,strokeColor=GRAY,strokeWidth=1,strokeDashArray=[4,3] if dashed else None))
        x,y=pts[0]; x2,y2=pts[1]
        if composition:
            dx,dy=(x2-x,y2-y); n=(dx*dx+dy*dy)**.5; ux,uy=dx/n,dy/n; px,py=-uy,ux
            points=[x,y,x+ux*5+px*3,y+uy*5+py*3,x+ux*10,y+uy*10,x+ux*5-px*3,y+uy*5-py*3]
            self.d.add(Polygon([c if i%2==0 else self.h-c for i,c in enumerate(points)],fillColor=INK,strokeColor=INK))
        if arrow:
            x,y=pts[-1]; xp,yp=pts[-2]; dx,dy=x-xp,y-yp; n=(dx*dx+dy*dy)**.5; ux,uy=dx/n,dy/n; px,py=-uy,ux
            self.d.add(PolyLine([x-ux*7+px*3,self.h-(y-uy*7+py*3),x,self.h-y,x-ux*7-px*3,self.h-(y-uy*7-py*3)],strokeColor=GRAY,strokeWidth=1))
        # End labels deliberately offset into whitespace.
        if a:
            x,y=pts[0]; xx,yy=pts[1]
            self.text(x+(4 if xx>=x else -5),y+(14 if xx==x else 15),a,8.2,align='start' if xx>=x else 'end')
        if b:
            x,y=pts[-1]; xx,yy=pts[-2]
            self.text(x+(5 if xx==x else (-4 if xx<x else 5)),y-6,b,8.2,align='end' if xx<x else 'start')
        if label:
            x,y=pts[len(pts)//2]; self.text(x+5,y-5,label,8.4,color=GRAY)
    def note(self,y,s): self.text(0,y,s,9,color=GRAY)
    def save(self):
        pdf=OUT/(self.name+'.pdf'); renderPDF.drawToFile(self.d,str(pdf))
        renderSVG.drawToFile(self.d,str(OUT/(self.name+'.svg')))
        p=fitz.open(pdf); p[0].get_pixmap(matrix=fitz.Matrix(2.5,2.5),alpha=False).save(OUT/(self.name+'.png')); p.close()

def build():
    d=Diagram('architecture',h=600)
    d.box(40,5,430,72,'Browser user interfaces', ['Customer site | Cashier console | Usher scan | Manager console'])
    d.link([(255,77),(255,110)],label='HTTPS requests and responses',arrow=True)
    d.box(40,110,430,69,'Request handlers and authorization', ['Validate input | Check session and current role | Enforce ownership'])
    d.link([(255,179),(255,207)],arrow=True)
    # One deployable app contains the six modules.
    d.d.add(Rect(0,600-211-160,510,160,fillColor=None,strokeColor=GRAY,strokeDashArray=[4,3],strokeWidth=.7))
    d.text(10,226,'One modular application server',10,True)
    mods=[('AuthService','Accounts and sessions'),('CatalogService','Movies and showtimes'),('BookingService','Holds and cancellations'),('PaymentService','Charges and refunds'),('TicketService','QR and admission'),('OperationsService','Shows, email and reports')]
    for i,(t,desc) in enumerate(mods):
        x=(i%3)*171+7; y=236+(i//3)*64
        d.box(x,y,154,54,t,[desc])
    d.link([(255,371),(255,414)],label='Transactional reads and writes',arrow=True)
    d.box(40,414,430,95,'DataStore and relational database', ['D1 Catalog | D2 Bookings and tickets | D3 Finance and audit', 'Account/session tables | Unique keys | Row locks | Durable work', 'One authoritative inventory shared by online and box-office sales'])
    d.box(0,537,240,54,'PaymentProvider', ['Charge | Refund | Signed events | Status'])
    d.box(270,537,240,54,'EmailProvider', ['Confirmation and account email'])
    d.link([(7,329),(0,329),(0,524),(120,524),(120,537)],arrow=True)
    d.link([(120,537),(120,524),(0,524),(0,329),(7,329)],arrow=True)
    d.link([(497,329),(510,329),(510,524),(390,524),(390,537)],arrow=True)
    d.text(8,387,'Workers: expiry and reconciliation;',8.7,color=GRAY)
    d.text(8,401,'show cancellation and email retry.',8.7,color=GRAY)
    d.save()

    d=Diagram('uml_catalog',h=600)
    d.box(0,0,238,158,'Movie',['- movieId: UUID','- title: String','- runtimeMinutes: UInt','- archived: Bool'],['+ update(details: MovieInput): Void','+ archive(): Void'])
    d.box(272,0,238,171,'Account',['- accountId: UUID','- email: String','- passwordHash: String','- roles: Set<Role>','- status: AccountStatus'],['+ hasRole(role: Role): Bool','+ isLoginAllowed(now: Instant): Bool'])
    d.box(0,232,238,184,'Showtime',['- showtimeId: UUID','- movieId, auditoriumId: UUID','- startsAt, endsAt: Instant','- status: ShowtimeStatus','- pricing: PricePolicy'],['+ isBookable(now: Instant): Bool','+ admissionWindow(): TimeRange','+ quote(seatCount: UInt): PriceQuote'])
    d.box(272,232,238,184,'Auditorium',['- auditoriumId: UUID','- name: String','- layoutVersion: UInt'],['+ validateLayout(','    seats: List<SeatInput>): Bool','+ canSchedule(start: Instant,','    end: Instant,','    existing: List<TimeRange>): Bool'])
    d.box(272,467,238,132,'Seat',['- seatId, auditoriumId: UUID','- label: String','- accessible: Bool'],['+ displayLabel(): String','+ setAccessibility(accessible: Bool): Void'])
    d.link([(105,158),(105,232)],'1','0..*')
    d.link([(272,324),(238,324)],'1','0..*')
    d.link([(386,416),(386,467)],'1','1..*',composition=True)
    d.note(488,'Cross-view links to UML 2:')
    d.note(508,'Account 0..1 -- 0..* Booking (customer)')
    d.note(528,'Showtime 1 -- 0..* Booking')
    d.note(548,'Showtime 1 owns 1..* ShowtimeSeat')
    d.note(568,'Seat 1 -- 0..* ShowtimeSeat')
    d.note(588,'Full fields and operation contracts: Section 6.6.')
    d.save()

    d=Diagram('uml_booking',h=606)
    d.box(0,0,238,184,'Booking',['- bookingId, showtimeId: UUID','- customerId: UUID?','- status: BookingStatus','- expiresAt: Instant','- quote: PriceQuote'],['+ isExpired(now: Instant): Bool','+ canCancel(now: Instant, start: Instant,','    allUnused: Bool): Bool'])
    d.box(272,0,238,171,'ShowtimeSeat',['- showtimeId, seatId: UUID','- ownerBookingId: UUID?','- status: SeatState','- version: UInt'],['+ claim(bookingId: UUID): Void','+ sell(bookingId: UUID): Void','+ release(bookingId: UUID): Bool'])
    d.box(0,244,238,145,'BookingSeat',['- bookingId, seatId: UUID','- seatLabelSnapshot: String','- seatPriceCents: Int64','- feeShareCents, taxShareCents: Int64'],['+ lineTotalCents(): Int64'])
    d.box(272,244,238,184,'Payment',['- paymentId, bookingId: UUID','- amountCents: Int64','- method: PaymentMethod','- status: PaymentStatus'],['+ matches(quote: PriceQuote): Bool','+ applyVerified(result: ProviderResult,','    now: Instant): Void','+ markUnknown(now: Instant): Void'])
    d.box(272,483,238,119,'Refund',['- refundId, paymentId: UUID','- amountCents: Int64','- status: RefundStatus'],['+ recordCashPaid(cashierId: UUID,','    now: Instant): Void'])
    d.link([(108,184),(108,244)],'1','1..8',composition=True)
    d.link([(238,77),(255,77),(272,77)],'0..1','0..8')
    d.link([(170,184),(170,211),(388,211),(388,244)],'1','0..1')
    d.link([(388,428),(388,483)],'1','0..1')
    d.note(455,'ShowtimeSeat stores current ownership.')
    d.note(475,'BookingSeat preserves historical selection.')
    d.note(495,'Unique Payment.bookingId: one attempt.')
    d.note(515,'Unique Refund.paymentId: one refund.')
    d.note(553,'To UML 3: BookingSeat 1 -- 0..1 Ticket')
    d.note(574,'A confirmed booking has 1..8 tickets.')
    d.note(596,'Black diamond = composition; lines = associations.')
    d.save()

    d=Diagram('uml_ticket',h=598)
    d.box(0,0,238,184,'Ticket',['- ticketId: UUID','- bookingId, seatId: UUID','- tokenHash: String','- encryptedToken: Bytes','- status: TicketStatus','- admittedAt: Instant?'],['+ admit(now: Instant): Bool','+ void(): Void'])
    d.box(272,0,238,171,'AdmissionAttempt',['- attemptId: UUID','- ticketId: UUID?','- usherId: UUID','- scannedAt: Instant','- result: AdmissionResult','- tokenFingerprint: String'],['+ isAccepted(): Bool'])
    d.box(0,260,238,184,'Notification',['- notificationId: UUID','- bookingId, accountId: UUID?','- kind: NotificationKind','- dedupeKey: String','- status: NotificationStatus','- nextAttemptAt: Instant'],['+ markSent(now: Instant): Void','+ scheduleRetry(next: Instant): Void'])
    d.box(272,260,238,223,'AuditEvent',['- eventId, requestId: UUID','- actorId: UUID?','- action, entityType: String','- entityId: UUID?','- occurredAt: Instant'],['+ record(action: String, entityType: String,','    entityId: UUID?, actorId: UUID?,','    requestId: UUID,','    details: Map<String,String>,','    now: Instant): AuditEvent'])
    d.link([(238,105),(272,105)],'0..1','0..*')
    d.note(219,'A ticket has many scan attempts; only one may be ACCEPTED.')
    d.note(516,'Cross-view associations:')
    d.note(536,'Booking 0..1 -- 0..* Notification; Account 0..1 -- 0..* Notification')
    d.note(556,'Account 1 -- 0..* AdmissionAttempt (usher)')
    d.note(576,'Account 0..1 -- 0..* AuditEvent (actor)')
    d.note(596,'AuditEvent.entityType/entityId identifies its affected business record.')
    d.save()

    d=Diagram('uml_services',h=622)
    specs=[
    ('AuthService',['- store: DataStore','- clock: Clock','- policy: AuthPolicy'],['+ login(email: String,','    password: String): Result<SessionView>','+ authorize(sessionToken: String,','    action: Action): Result<ActorContext>']),
    ('CatalogService',['- store: DataStore','- clock: Clock'],['+ search(filter: CatalogFilter):','    List<ShowtimeView>','+ seatMap(showtimeId: UUID):','    Result<List<SeatView>>']),
    ('BookingService',['- store: DataStore','- clock: Clock'],['+ createHold(actor: ActorContext,','    request: HoldRequest, key: UUID):','    Result<BookingView>','+ expireHolds(now: Instant,','    limit: UInt): UInt']),
    ('PaymentService',['- store: DataStore','- provider: PaymentProvider','- clock: Clock'],['+ handleProviderEvent(event: ProviderEvent,','    signature: String): Result<Void>','+ processRefund(refundId: UUID):','    Result<RefundView>']),
    ('TicketService',['- store: DataStore','- crypto: TokenProtector','- clock: Clock'],['+ issue(bookingId: UUID): List<Ticket>','+ validate(actor: ActorContext,','    qrToken: String, attemptId: UUID):','    Result<AdmissionDecision>']),
    ('OperationsService',['- store: DataStore','- email: EmailProvider','- clock: Clock'],['+ cancelShow(actor: ActorContext,','    showtimeId: UUID, reason: String,','    key: UUID):','    Result<CancellationSummary>','+ processShowCancellation(','    showtimeId: UUID, limit: UInt): UInt'])]
    for i,(title,attrs,ops) in enumerate(specs):
        d.box((i%2)*272,(i//2)*204,238,192,title,attrs,ops)
    # Common dependencies are stated once to keep signatures legible.
    d.note(618,'All services depend on DataStore and Clock. Complete interfaces: Section 6.7.')
    d.save()

if __name__=='__main__': build()
